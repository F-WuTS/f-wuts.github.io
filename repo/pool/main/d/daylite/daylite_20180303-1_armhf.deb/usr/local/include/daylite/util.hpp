#ifndef _DAYLITE_UTIL_HPP_
#define _DAYLITE_UTIL_HPP_

namespace daylite
{
  void register_signal_handlers();
  bool should_exit();
}

#endif