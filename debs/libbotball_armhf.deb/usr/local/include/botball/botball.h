#ifndef _BOTBALL_H_
#define _BOTBALL_H_

#ifdef __cplusplus
extern "C" {
#endif

void shut_down_in(double s);

void wait_for_light(int light_port_);

#ifdef __cplusplus
}
#endif

#endif
