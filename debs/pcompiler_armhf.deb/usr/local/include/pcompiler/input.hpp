#ifndef _INPUT_HPP_
#define _INPUT_HPP_

#include <QSet>
#include <QString>

namespace Compiler
{
	typedef QSet<QString> Input;
}

#endif
